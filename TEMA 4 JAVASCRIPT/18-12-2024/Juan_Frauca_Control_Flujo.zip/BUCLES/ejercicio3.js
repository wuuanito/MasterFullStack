/*

Mostrar en pantalla los números del 10 al 20 (incluidos los dos) con una línea vacía entre ellos.
*/

for (let i = 10 ; i<= 20 ; i++){
    console.log(i)
    console.log()
}