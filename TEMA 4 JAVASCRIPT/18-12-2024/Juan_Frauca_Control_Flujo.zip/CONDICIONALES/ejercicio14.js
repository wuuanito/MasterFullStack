/* 

Escribe un programa que muestre la fecha de hoy


*/

const fecha = new Date()


console.log(fecha)